//Enums.cpp

#include "stdafx.h"

#include "Enums.h"

Enums::Enums()
{

}